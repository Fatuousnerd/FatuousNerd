NOTE:
By installing or using this font, you are agree to the Product Usage Agreement:

- This font is already FULL VERSION and ONLY for PERSONAL USE. NO COMMERCIAL USE ALLOWED!

- Here is the link to purchase COMMERCIAL LICENSE:
https://www.creativefabrica.com/product/osake/ref/238083/

- If you need a CUSTOM LICENSE or CORPORATE LICENSE please contact us at: stringlabscreative@gmail.com

- Any donation are very appreciated. Our Paypal account for donation :
https://paypal.me/stringlabs

Please visit our store for more amazing fonts :
https://www.creativefabrica.com/product/hollywise/ref/238083/

Follow our instagram : @stringlabscreativestd

Thank you.

-------------------

INDONESIA:
Dengan meng-install font ini, dan membaca persyaratan ini, anda dianggap mengerti dan menyetujui semua syarat dan ketentuan penggunaan font dibawah ini:

- Font demo ini hanya dapat digunakan untuk keperluan "Personal Use"/kebutuhan pribadi, atau untuk keperluan yang sifatnya tidak "komersil", alias tidak menghasilkan profit atau keuntungan dari hasil memanfaatkan/menggunakan font kami. Baik itu untuk individu, Agensi Desain Grafis, Percetakan, Distro atau Perusahaan/Korporasi.   

- Silakan gunakan lisensi komersial dengan membeli melalui link ini :
https://www.creativefabrica.com/product/osake/ref/238083/

- Dengan hanya lisensi "Personal Use", DILARANG KERAS menggunakan atau memanfaatkan font ini untuk kepeluan Komersial, baik itu untuk Iklan, Promosi, TV, Film, Video, Motion Graphics, Youtube, Desain kaos distro atau untuk Kemasan Produk (baik Fisik ataupun Digital) atau Media apapun dengan tujuan menghasilkan profit/keuntungan.

- Untuk penggunaan keperluan Perusahaan/Korporasi silakan menggunakan CUSTOM LICENSE.

- Menggunakan font ini dengan lisensi "Personal Use" untuk kepentingan Komersial apapun bentuknya TANPA IZIN dari kami, akan dikenakan biaya EXTENDED LICENSE atau 100x Harga lisensi desktop.

- Saya hanya menerima "lisensi font" sebelum penggunaan

- Saya tidak menerima "lisensi font" setelah penggunaan. (Contoh kasus: anda ketahuan menggunakan font saya untuk keperluan komersil, padahal lisensinya free for personal use, kemudian setelah ketahuan menggunakan font saya, anda membeli lisensinya di link diatas. Nah untuk kejadian yg seperti ini saya tidak akan "MENERIMA LISENSINYA", karena lisensi font yang anda beli adalah "LISENSI SETELAH PENGGUNAAN")

- Lisensi font setelah penggunaan silahkan gunakan sesuai terms & condition yang berlaku setelah anda membeli lisensi font tersebut

Informasi tentang Lisensi apa yang akan anda perlukan, silahkan menghubungi kami di : stringlabscreative@gmail.com

Terima kasih.



